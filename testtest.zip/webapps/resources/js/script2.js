
const header_left_button = document.getElementById('header_left_button');
const side_menu = document.getElementById('side_menu');


function handleClick1() {
    if (side_menu.style.display == 'none'){
        side_menu.style.display = 'block';
    } else {
        side_menu.style.display = 'none';
    }
}

header_left_button.onclick = handleClick1;