import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

@WebServlet(name = "SecondServlet", urlPatterns = "/second-servlet")
public class Write extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        HashMap hashMap = new HashMap();
        hashMap.put("b_Title", req.getParameter("b_Title"));
        hashMap.put("b_Detail", req.getParameter("b_Detail"));

        sqlSession.insert("mybatis.mappers.writeBoardMapper.insertWriteBoard",hashMap);
        sqlSession.commit();
        sqlSession.close();


    }
}