package model;

public class WriteBoard {
    private int b_Id;
    private String b_Title;
    private String b_Detail;

    public int getB_Id() {
        return b_Id;
    }

    public void setB_Id(int b_Id) {
        this.b_Id = b_Id;
    }

    public String getB_Title() {
        return b_Title;
    }

    public void setB_Title(String b_Title) {
        this.b_Title = b_Title;
    }

    public String getB_Detail() {
        return b_Detail;
    }

    public void setB_Detail(String b_Detail) {
        this.b_Detail = b_Detail;
    }

    @Override
    public String toString() {
        return "WriteBoard{" +
                "b_Id=" + b_Id +
                ", b_Title='" + b_Title + '\'' +
                ", b_Detail='" + b_Detail + '\'' +
                '}';
    }
}
