package model;

public class Board {
    private int uid;
    private String id;
    private String pw;

    public int getUid() {
        return uid;
    }

    public String getId() {
        return id;
    }

    public String getPw() {
        return pw;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    @Override
    public String toString() {
        return "Board{" +
                "uid=" + uid +
                ", id='" + id + '\'' +
                ", pw='" + pw + '\'' +
                '}';
    }
}
